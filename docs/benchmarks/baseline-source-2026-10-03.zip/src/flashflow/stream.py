import asyncio
import json
import logging
import time
from collections import Counter
from contextlib import suppress
from datetime import datetime, timezone

from aiokafka import AIOKafkaConsumer, AIOKafkaProducer, TopicPartition
from fastapi import WebSocket
from redis.asyncio import Redis
from redis.exceptions import RedisError
from sqlalchemy.exc import SQLAlchemyError

from .config import settings
from .inventory import process_event
from .pricing import apply_decision, publish_decision
from aiokafka.errors import KafkaError
from .schemas import EventEnvelope
from .resilience import DependencyUnavailable

from .timing import timings

logger = logging.getLogger("flashflow")


class ConnectionManager:
    def __init__(self):
        self.clients: set[asyncio.Queue] = set()
        self.counters = Counter()

    def connect(self) -> asyncio.Queue:
        queue = asyncio.Queue(maxsize=100)
        self.clients.add(queue)
        logger.info(json.dumps({"action": "client_connected", "clients": len(self.clients)}))
        return queue

    def disconnect(self, queue):
        self.clients.discard(queue)
        logger.info(json.dumps({"action": "client_disconnected", "clients": len(self.clients)}))

    def broadcast(self, message: dict):
        started = time.perf_counter()
        for queue in tuple(self.clients):
            if queue.full():
                # Disconnect slow clients; reconnect fetches a durable snapshot.
                while not queue.empty():
                    queue.get_nowait()
                queue.put_nowait(None)
                self.counters["slow_disconnects"] += 1
                self.disconnect(queue)
            else:
                queue.put_nowait(message)

        timings.observe("websocket_enqueue", (time.perf_counter() - started) * 1000)

    async def serve(self, socket: WebSocket):
        await socket.accept()
        queue = self.connect()

        async def send():
            while True:
                try:
                    message = await asyncio.wait_for(queue.get(), settings.websocket_heartbeat_seconds)
                except TimeoutError:
                    message = {"type": "heartbeat"}
                if message is None:
                    await socket.close(code=1013)
                    return
                if message.get("type") == "product_update":
                    message = {**message, "websocket_sent_at": datetime.now(timezone.utc).isoformat()}
                    timings.observe("websocket_queue", (datetime.now(timezone.utc) - datetime.fromisoformat(message["emitted_at"])).total_seconds() * 1000)
                try:
                    with timings.measure("websocket_send"):
                        await asyncio.wait_for(socket.send_json(message), settings.websocket_heartbeat_seconds)
                except Exception:
                    self.counters["failed_sends"] += 1
                    raise
                if message.get("type") == "product_update":
                    self.counters["sent"] += 1

        async def receive():
            while True:
                if await asyncio.wait_for(socket.receive_text(), settings.websocket_heartbeat_seconds * 3) != "pong":
                    await socket.close(code=1008)
                    return

        tasks = [asyncio.create_task(send()), asyncio.create_task(receive())]
        try:
            done, _ = await asyncio.wait(tasks, return_when=asyncio.FIRST_COMPLETED)
            for task in done:
                with suppress(Exception):
                    task.result()
        finally:
            self.disconnect(queue)
            for task in tasks:
                task.cancel()
            await asyncio.gather(*tasks, return_exceptions=True)


class InventoryConsumer:
    def __init__(self, manager: ConnectionManager, faults=None):
        self.manager = manager
        self.faults = faults
        self.counters = Counter()
        self.redis = Redis.from_url(settings.redis_url, socket_timeout=1, socket_connect_timeout=1)
        self.consumer = AIOKafkaConsumer(settings.kafka_inventory_topic, settings.kafka_pricing_topic,
            bootstrap_servers=settings.kafka_bootstrap_servers, group_id=settings.kafka_consumer_group,
            enable_auto_commit=False, auto_offset_reset="earliest", max_poll_interval_ms=300000)
        self.producer = AIOKafkaProducer(bootstrap_servers=settings.kafka_bootstrap_servers)

    async def handle(self, record):
        received_at = datetime.now(timezone.utc)
        started = time.perf_counter()
        for attempt in range(1, settings.consumer_max_attempts + 1):
            try:
                raw = json.loads(record.value)
                if not isinstance(raw, dict) or not {"event_id", "event_type", "product_id", "timestamp", "schema_version", "source", "payload"} <= raw.keys():
                    raise ValueError("event envelope is missing required fields")
                event = EventEnvelope.model_validate_json(record.value)
                if event.schema_version != "1.0" or event.timestamp.tzinfo is None:
                    raise ValueError("unsupported schema version or naive timestamp")
                if record.key != str(event.product_id).encode():
                    raise ValueError("Kafka key must match product_id")
                timings.observe("producer_to_consumer", (received_at - event.timestamp).total_seconds() * 1000)
                processing_at = datetime.now(timezone.utc)
                with timings.measure("database"):
                    product, outcome = await (apply_decision(event) if record.topic == settings.kafka_pricing_topic else process_event(event))
                if record.topic == settings.kafka_inventory_topic:
                    with timings.measure("pricing_publish"):
                        await publish_decision(event, self.producer)
                if getattr(self, "faults", None) and self.faults.redis_unavailable:
                    raise DependencyUnavailable("Redis failure injected")
                # Replays repair cache/broadcast after a database commit interrupted by failure.
                with timings.measure("redis"):
                    await self.redis.set(f"product:{product.product_id}", product.model_dump_json())
                self.manager.broadcast({"type": "product_update", "event_id": str(event.event_id), "event_at": event.timestamp.isoformat(),
                                        "kafka_received_at": received_at.isoformat(), "processing_started_at": processing_at.isoformat(),
                                        "processing_finished_at": datetime.now(timezone.utc).isoformat(),
                                        "emitted_at": datetime.now(timezone.utc).isoformat(), "product": product.model_dump(mode="json")})
                timings.observe("processing", (time.perf_counter() - started) * 1000)
                self.counters["completed"] += 1
                self.counters[outcome] += 1
                return
            except Exception as error:
                self.counters["failed"] += 1
                logger.warning(json.dumps({"action": "event_failed", "partition": record.partition, "offset": record.offset, "attempt": attempt, "error": str(error)}))
                if attempt < settings.consumer_max_attempts:
                    if not isinstance(error, ValueError):
                        await asyncio.sleep(settings.consumer_retry_seconds * 2 ** (attempt - 1))
                else:
                    if isinstance(error, (ConnectionError, TimeoutError, RedisError, SQLAlchemyError, KafkaError)):
                        # Infrastructure outages retain the Kafka offset; only bad events go to DLQ.
                        raise
                    failure = {"topic": record.topic, "partition": record.partition, "offset": record.offset,
                               "key": record.key.hex() if record.key else None, "raw_value_hex": record.value.hex(),
                               "error": str(error), "attempts": attempt, "timestamp": datetime.now(timezone.utc).isoformat()}
                    await self.producer.send_and_wait(settings.kafka_dlq_topic, key=record.key, value=json.dumps(failure).encode())
                    self.counters["dlq"] += 1

    async def run(self):
        try:
            await self.producer.start()
            await self.consumer.start()
            async for record in self.consumer:
                self.counters["kafka_received"] += 1
                if record.topic == settings.kafka_pricing_topic:
                    self.counters["pricing_received"] += 1
                # Failed DLQ publication or commit retains this offset and retries the same record.
                while True:
                    try:
                        while getattr(self, "faults", None) and self.faults.consumer_paused:
                            await asyncio.sleep(0.2)
                        await self.handle(record)
                        with timings.measure("offset_commit"):
                            await self.consumer.commit({TopicPartition(record.topic, record.partition): record.offset + 1})
                        break
                    except Exception as error:
                        logger.error(json.dumps({"action": "consumer_retry", "error": str(error)}))
                        await asyncio.sleep(max(settings.consumer_retry_seconds, 0.1))
        finally:
            await self.consumer.stop()
            await self.producer.stop()
            await self.redis.aclose()
